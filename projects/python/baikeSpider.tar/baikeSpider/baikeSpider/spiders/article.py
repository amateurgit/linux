import scrapy

class articleSpider(scrapy.Spider):
    name='article'

    def start_requests(self):
        urls = [
                'https://baike.baidu.com/item/Python/407313',
                'https://baike.baidu.com/item/%E5%88%98%E5%BE%B7%E5%8D%8E/114923'
                ]
        return [scrapy.Request(url=url, callback=self.parse)
                for url in urls]

    def parse(self, response):
        url = response.url
        title = response.css('title::text').extract_first()
        print('URL is : {}'.format(url))
        print('Title is : {}'.format(title))
