from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from baikeSpider.items import Article

class ArticleSpider(CrawlSpider):
	name='articlePipelines'
	allowed_domains = ['baike.baidu.com']
	start_urls = ['https://baike.baidu.com/item/%E5%88%98%E5%BE%B7%E5%8D%8E/114923']
	rules = [Rule(LinkExtractor(allow=r'.*'), follow=True, callback='parse_items')]

	def parse_items(self, response):
		article = Article()
		article['url'] = response.url
		article['title'] = response.css('title::text').extract_first()
		return article
