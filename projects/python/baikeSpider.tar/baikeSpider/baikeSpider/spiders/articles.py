from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

class ArticleSpider(CrawlSpider):
	name='articles'
	allowed_domains = ['baike.baidu.com']
	start_urls = ['https://baike.baidu.com/item/%E5%88%98%E5%BE%B7%E5%8D%8E/114923']
	rules = [Rule(LinkExtractor(allow=r'.*'), follow=True, callback='parse_items')]

	def parse_items(self, response):
		url = response.url
		title = response.css('title::text').extract_first()
		print('URL is : {}'.format(url))
		print('Title is : {}'.format(title))
